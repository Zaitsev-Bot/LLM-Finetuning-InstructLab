# SPDX-License-Identifier: Apache-2.0

# First Party
from instructlab import lab

lab.ilab(None, None)
