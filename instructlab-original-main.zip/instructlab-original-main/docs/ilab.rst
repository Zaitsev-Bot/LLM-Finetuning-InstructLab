ilab command line reference
===========================

The following documentation is auto-generated from the ``ilab`` code.

.. click:: instructlab.lab:ilab
   :prog: ilab
   :nested: full
