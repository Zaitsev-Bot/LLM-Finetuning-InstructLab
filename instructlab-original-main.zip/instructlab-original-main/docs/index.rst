Welcome to InstructLab's documentation!
=======================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   ilab.rst
   gpu-acceleration.md
   amd-rocm.md
   habana-gaudi.md
   converting_GGUF.md
   ci.md
   demo-slides.md
   README.md
   release-strategy.md
   instructlab_models.md
   PROMPTING-FAQ.md


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
